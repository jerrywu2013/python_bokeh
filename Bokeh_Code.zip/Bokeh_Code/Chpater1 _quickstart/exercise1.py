# Import figure from bokeh.plotting
from bokeh.plotting import ___

# Import output_file and show from bokeh.io
from bokeh.io import ___, ___

# Create the figure: p
p = ____(____='fertility (children per woman)', ____='female_literacy (% population)')

# Add a circle glyph to the figure p
p.circle(____, ____)

# Call the output_file() function and specify the name of the file


# Display the plot