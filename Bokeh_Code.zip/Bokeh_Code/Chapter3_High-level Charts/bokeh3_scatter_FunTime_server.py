#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  3 00:00:05 2017

@author: jerry
"""
from bokeh.io import curdoc
from bokeh.charts import Scatter, output_file, show
from bokeh.sampledata.iris import flowers as df
import pandas as pd

df = pd.read_csv('stock.csv', 
                 encoding = 'big5',
                 sep = ',',
                 header = 1)
df = df[0:30]
df.columns = ['Index',
              'Closing_Index',
              'Gains',
              'Gains_index',
              'Gains_percentage']

p = Scatter(df, x='Closing_Index', y='Gains_percentage',
            marker='Gains', color='Gains', title='106年03月31日大盤統計資訊',
            xlabel='收盤指數', ylabel='漲跌百分比(%)')

#Configure title attribute
p.title.text = "106年03月31日大盤統計資訊"
p.title.align = "center"
#p.title.text_color = "orange"
p.title.text_font_size = "15px"
#p.title.background_fill_color = "#aaaaee"


p.yaxis.axis_label_text_font_style = "italic"
p.xaxis.axis_label_text_font_style = "italic"

p.yaxis.axis_label_text_font_size = "15px"
p.xaxis.axis_label_text_font_size = "15px"



#output_file('Scatter_Stock.html')
#show(p)

curdoc().add_root(p)




