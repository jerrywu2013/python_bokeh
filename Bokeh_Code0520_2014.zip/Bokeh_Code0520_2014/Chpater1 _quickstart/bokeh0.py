from bokeh.io import show
from bokeh.plotting import figure

plot = figure(plot_width=400,
             y_axis_label='new',
             x_axis_label='new2',
             title="這是我第一張圖")

plot.circle([1,2,3,4,5],
            [2,3,4,5,6],
            fill_color="#F0027F",
            line_color="#F0027F",
            size=10,
            legend="數值說明")
show(plot)


