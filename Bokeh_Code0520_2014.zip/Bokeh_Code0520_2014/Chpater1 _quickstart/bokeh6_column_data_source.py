#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr  2 12:00:04 2017

@author: jerry
"""

from bokeh.models import ColumnDataSource
from bokeh.sampledata.iris import flowers as df

print(df.head())
source = ColumnDataSource(df)

print(source)


##############################

from bokeh.io import output_file, show
from bokeh.plotting import figure
from bokeh.sampledata.iris import flowers as df
from bokeh.plotting import ColumnDataSource

source = ColumnDataSource(df)

plot = figure()

source = ColumnDataSource(df)

plot.circle(x='petal_length',
            y='sepal_length',
            source=source)

output_file('sprint.html')
show(plot)
