#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr  2 16:08:39 2017

@author: jerry
"""
from bokeh.plotting import figure
from bokeh.io import output_file, show
from bokeh.layouts import row

TSMC = [204.00, 203.50, 203.00, 202.50, 202.00, 201.50]
ASUS = [284.00, 283.50, 283.00, 282.50, 282.00, 281.50]

TSMC_amount = [2, 151, 1, 1, 1, 1, 1, 8, 2]
ASUS_amount = [13, 2368, 1, 1, 1, 4, 27, 4, 151]

p1 = figure(title='05/18量價變化圖',
            x_axis_label='TSMC',
            y_axis_label='ASUS')
p1.circle(TSMC, ASUS, size=10)

p2 = figure(title='05/18最後交易量(張)',
            x_axis_label='TSMC',
            y_axis_label='ASUS')
p2.circle(TSMC_amount, ASUS_amount, size=10)

layout = row(p1, p2)
output_file('layouts.html', mode='inline')
show(layout)



