#!/usr/bin/env python3
#-*- coding: utf-8 -*-
"""
Created on Mon Apr  3 09:22:59 2017

@author: jerry
"""

##################################

from bokeh.io import curdoc
from bokeh.layouts import column
from bokeh.models import ColumnDataSource, Select
from bokeh.plotting import figure
from numpy.random import random, normal, lognormal
import pandas as pd

#N = 300 
source = ColumnDataSource(data={'x': random(N), 'y': random(N)})

TSMC = [204.00, 203.50, 203.00, 202.50, 202.00, 201.50]
ASUS = [284.00, 283.50, 283.00, 282.50, 282.00, 281.50]

TSMC_amount = [2, 151, 1, 1, 1, 1, 1, 8, 2]
ASUS_amount = [13, 2368, 1, 1, 1, 4, 27, 4, 151]

Stock_df = pd.DataFrame({'TSMC': TSMC, 'ASUS': ASUS})
Amount_df = pd.DataFrame({'TSMC': TSMC_amount, 'ASUS': ASUS_amount})

plot = figure()
plot.circle(x= 'x', y= 'y', source=source)

menu = Select(options=['Stock_df',
                       'Amount_df'],
                        value='Stock_df', title='股票分析平台')

##################################

def callback(attr, old, new):
    if   menu.value == 'Amount_df': f = Amount_df
#    elif menu.value == 'normal':  f = normal
    else:                           f = Stock_df 
    source.data = {'x': f['TSMC'], 'y': f['ASUS']}

menu.on_change('value', callback)

layout = column(menu, plot)

curdoc().add_root(layout)