#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat May 20 07:21:06 2017

@author: jerry
"""
from bokeh.charts import Bar, show
import pandas as pd


X = [1,2,3,3,4,4,5,6]
X_data = pd.DataFrame({'cyl': X })
X_data = pd.value_counts(X_data.cyl)

p = Bar(X_data, 'index',
        values='cyl',
        title="Total Index by CYL",
        color="blue")

#output_file("bar.html")

show(p)